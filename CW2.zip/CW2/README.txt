The program is a student monitoring system as outlined in the coursework. It is important to note that diagrams will appear as pop-ups
and any writing in the form of student grades will appear in the Python Shell. The menu.py file incorporates the use of the tkinter GUI
menu. Any errors may be as a result of invalid student ID being input. However, this has been handled and an error message will be displayed
on the Python shell if an invalid student ID is put: for example, print("Student ID not found in test2 database") is used in testResults.py.
Each of the problem questions has been answered in this coursework.